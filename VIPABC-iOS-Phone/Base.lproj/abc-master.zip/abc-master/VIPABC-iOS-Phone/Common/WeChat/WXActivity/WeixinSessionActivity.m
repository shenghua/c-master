//
//  WeixinSessionActivity.m
//  WeixinActivity
//
//  Created by Johnny iDay on 13-12-2.
//  Copyright (c) 2013年 Johnny iDay. All rights reserved.
//

#import "WeixinSessionActivity.h"

@implementation WeixinSessionActivity

- (UIImage *)_activityImage
{
    return [UIImage imageNamed:@"wx_session"];
}

- (NSString *)activityTitle
{
    return @"微信好友";
}

@end
