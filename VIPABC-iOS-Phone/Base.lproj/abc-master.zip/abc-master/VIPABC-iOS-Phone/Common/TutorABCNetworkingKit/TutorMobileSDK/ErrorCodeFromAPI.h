//
//  ErrorCodeFromAPI.h
//  TutorMobile
//
//  Created by Eddy Tsai_蔡佳翰 on 2015/9/22.
//  Copyright (c) 2015年 TutorABC. All rights reserved.
//

#ifndef TutorMobile_ErrorCodeFromAPI_h
#define TutorMobile_ErrorCodeFromAPI_h



#define STR_ERROR_DOMAIN @"com.TutorABC.TutorMobile.error"

// learning history
#define STR_STATUS_SUCCESS @100000


#endif
