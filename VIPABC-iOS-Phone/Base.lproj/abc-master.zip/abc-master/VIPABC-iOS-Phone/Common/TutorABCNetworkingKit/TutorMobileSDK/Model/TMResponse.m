//
//  TMResponse.m
//  TutorMobile
//
//  Created by Tony Tsai_蔡豐屹 on 9/21/15.
//  Copyright (c) 2015 TutorABC. All rights reserved.
//

#import "TMResponse.h"

@implementation TMArrayResponse

@end

@implementation TMDictResponse

@end

@implementation TMStatus

@end


