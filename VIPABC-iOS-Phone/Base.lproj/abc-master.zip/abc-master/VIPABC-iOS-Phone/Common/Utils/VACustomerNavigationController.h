//
//  VACustomerViewController.h
//  VIPABC-iOS-Phone
//
//  Created by ledka on 16/2/1.
//  Copyright © 2016年 vipabc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VACustomerNavigationController : UINavigationController

@property (nonatomic, assign) BOOL allowLandscape;
@property (nonatomic, assign) BOOL onlyLandscape;

@end
