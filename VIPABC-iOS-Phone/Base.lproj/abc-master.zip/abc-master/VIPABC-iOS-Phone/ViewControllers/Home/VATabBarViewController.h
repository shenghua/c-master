//
//  VATapViewController.h
//  VIPABC4Phone
//
//  Created by ledka on 15/11/26.
//  Copyright © 2015年 vipabc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VABaseViewController.h"

@interface VATabBarViewController : UITabBarController <UITabBarControllerDelegate>

@end
