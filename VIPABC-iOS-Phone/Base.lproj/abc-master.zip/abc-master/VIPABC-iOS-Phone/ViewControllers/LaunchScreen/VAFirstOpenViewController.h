//
//  VAFirstOpenViewController.h
//  VIPABC-iOS-Phone
//
//  Created by ledka on 16/2/23.
//  Copyright © 2016年 vipabc. All rights reserved.
//

#import "VABaseViewController.h"

@interface VAFirstOpenViewController : VABaseViewController

@end
