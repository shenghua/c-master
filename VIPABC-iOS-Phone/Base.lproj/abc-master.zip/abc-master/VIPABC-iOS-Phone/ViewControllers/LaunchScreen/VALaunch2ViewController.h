//
//  VALaunchViewController.h
//  VIPABC4Phone
//
//  Created by ledka on 16/1/6.
//  Copyright © 2016年 vipabc. All rights reserved.
//

#import "VABaseViewController.h"

@interface VALaunch2ViewController : VABaseViewController

@end
