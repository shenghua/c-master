//
//  MyProtocol.h
//  WebViewSample
//
//  Created by ledka on 15/12/18.
//  Copyright © 2015年 vipabc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VAWebViewURLProtocol : NSURLProtocol

@end
