//
//  VARegisterViewController.h
//  VIPABC4Phone
//
//  Created by uther on 16/1/14.
//  Copyright © 2016年 vipabc. All rights reserved.
//

#import "VABaseViewController.h"

@interface VARegisterViewController : VABaseViewController

@end
