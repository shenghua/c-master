//
//  VARegisterUserInfoViewController.h
//  VIPABC4Phone
//
//  Created by ledka on 15/11/27.
//  Copyright © 2015年 vipabc. All rights reserved.
//

#import "VABaseViewController.h"

@interface VARegisterUserInfoViewController : VABaseViewController

@end
