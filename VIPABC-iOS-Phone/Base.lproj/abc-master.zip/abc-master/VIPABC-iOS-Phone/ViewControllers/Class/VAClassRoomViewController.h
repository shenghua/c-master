//
//  VAClassRoomViewController.h
//  VIPABC4Phone
//
//  Created by ledka on 16/1/9.
//  Copyright © 2016年 vipabc. All rights reserved.
//

#import "VABaseViewController.h"

@interface VAClassRoomViewController : VABaseViewController

@end
