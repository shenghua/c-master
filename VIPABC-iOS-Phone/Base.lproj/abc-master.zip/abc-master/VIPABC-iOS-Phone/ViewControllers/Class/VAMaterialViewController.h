//
//  VAMaterialViewController.h
//  VIPABC4Phone
//
//  Created by ledka on 16/1/13.
//  Copyright © 2016年 vipabc. All rights reserved.
//

#import "VABaseViewController.h"
#import "TMClassInfo.h"

@interface VAMaterialViewController : VABaseViewController <UIScrollViewDelegate>

@property (strong, nonatomic) TMClassInfo *classinfo;

@end
