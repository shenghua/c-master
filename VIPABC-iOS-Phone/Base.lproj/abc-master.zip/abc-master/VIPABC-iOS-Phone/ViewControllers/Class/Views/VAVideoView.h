//
//  VAVideoView.h
//  VIPABC-iOS-Phone
//
//  Created by ledka on 16/1/19.
//  Copyright © 2016年 vipabc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VAVideoView : UIView

@property (nonatomic, assign) BOOL moveable;
@property (nonatomic, assign) float movedX;
@property (nonatomic, assign) float movedY;

@end
