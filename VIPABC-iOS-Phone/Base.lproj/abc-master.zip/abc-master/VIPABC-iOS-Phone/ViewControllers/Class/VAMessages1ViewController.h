//
//  VAMessages1ViewController.h
//  VIPABC-iOS-Phone
//
//  Created by ledka on 16/1/21.
//  Copyright © 2016年 vipabc. All rights reserved.
//

#import "VABaseViewController.h"

@interface VAMessages1ViewController : VABaseViewController

@end
