//
//  VABaseModel.m
//  VIPABC4Phone
//
//  Created by ledka on 15/11/30.
//  Copyright © 2015年 vipabc. All rights reserved.
//

#import "VABaseModel.h"

@implementation VABaseModel

@end
